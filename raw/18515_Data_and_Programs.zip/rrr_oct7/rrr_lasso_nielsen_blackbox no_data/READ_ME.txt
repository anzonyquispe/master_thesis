main_nielsen.R produces the tables corresponding to the Nielsen application

the data are not publicly available, but we do provide the code
########
# set up
########

rm(list=ls())

library("foreign")
library("dplyr")
library("ggplot2")
library("quantreg")

library("MASS")
library("glmnet")	#lasso, group lasso, and ridge, for outcome models, LPM, mlogit. Also, unpenalized mlogit via glmnet is far faster than the mlogit package.
library("grplasso")	#glmnet group lasso requires the same n per group (ie multi-task learning), which is perfect for mlogit but wrong for the outcome model.
# library("mlogit")	#slower than unpenalized estimation in glmnet, but glmnet won't fit only an intercept
library("nnet")	#quicker multinomial logit
library("keras")
library("randomForest")
library("gglasso")
library("plotrix")
library("gridExtra")

setwd("~/Documents/research/rrr_lasso_NSW_blackbox")

#######################
# clean and format data
#######################

source('data_cleaning.R') #from raw files
source('specifications.R') #4 specifications
source('specifications_intersection.R') # intersection of comparison groups across specs

dfs<-list(nsw,psid,cps)
df_names<-c('nsw','psid','cps')

intersection=1
#0 numerical support imposed separately for each spec
#1 numerical support imposed across all spec

specs<-3

for(i in 1:length(dfs)){
  df=dfs[[i]]
  for(j in length(specs)){
    spec=specs[j]
    
    paste('dataset: ')
    paste(df_names[i])
    paste('specification: ')
    paste(spec)
      
    if(intersection){
      data<-get_data_intersection(df,spec) #(nsw, psid, cps) then choice of (1,2,3)
    } else {
      data<-get_data(df,spec) #(nsw, psid, cps) then choice of (1,2,3)
    }
      


Y=data[[1]]
T=data[[2]]
X=data[[3]] #no intercept

##################
# helper functions
##################

source('primitives.R')

# dictionary
dict=b2 # b for partially linear model, b2 for interacted model. shows up in stage1.R for NN
p=length(dict(T[1],X[1,]))
n=length(T)

########
# tuning
########

source('stage0.R') #stage0.R before cv.R since cv.R calls RMD_lasso and RMD_dantzig
source('cv.R')

# iteration
p0=ceiling(p/4)  #p0=dim(X0) used in low-dim dictionary in the stage 1 iterative tuning procedure
if (p>60){
  p0=ceiling(p/40)
}
D_LB=0 #each diagonal entry of \hat{D} lower bounded by D_LB
D_add=.2 #each diagonal entry of \hat{D} increased by D_add
max_iter=10 #max number iterations in Dantzig selector iteration over estimation and weights

# cross validation
set.seed(1)
c_vals=c(5/4,1,3/4,1/2)*0.5 # 0.5 since objective has 2r x |rho|
#c_RR=get_cv_rr(Y,T,X,p0,D_LB,D_add,max_iter,dict,1,0,c_vals) # Dantzig
c_RR=get_cv_rr(Y,T,X,p0,D_LB,D_add,max_iter,dict,1,1,c_vals)
print(paste0("c RR vals: ",c_vals))
print(paste0("c RR: ",c_RR))

#c_CEF=get_cv_rr(Y,T,X,p0,D_LB,D_add,max_iter,dict,0,0,c_vals) # Dantzig
#c_CEF=get_cv_rr(Y,T,X,p0,D_LB,D_add,max_iter,dict,0,1,c_vals)
#print(paste0("c CEF vals: ",c_vals))
#print(paste0("c CEF: ",c_CEF))

###########
# algorithm
###########

# to debug

source('stage1.R') #stage1.R after cv.R to incorporate tuned hyperparameters
source('stage2.R')

set.seed(1) # for sample splitting

alpha_estimator=1
gamma_estimator=5
bias=0

#alpha_estimator: #0 dantzig, 1 lasso

#gamma_estimator: 
#0 dantzig, 1 lasso, 2 rf 
#3 nn (1 layer, linout=FALSE), 4 nn2 (1 layer, linout=TRUE), 5 nn3 (2 layer)

#bias: 0 DML, 1 plug-in

results<-rrr(Y,T,X,p0,D_LB,D_add,max_iter,dict,alpha_estimator,gamma_estimator,bias,c_RR,c_CEF)
printer(results)
for_tex(results)

  }
}
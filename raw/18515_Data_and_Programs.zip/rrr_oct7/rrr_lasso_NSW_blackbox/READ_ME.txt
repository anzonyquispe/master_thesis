main_nsw.R produces the tables for the NSW application
simulation.R produces the tables for the simulation in the appendix
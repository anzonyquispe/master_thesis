#––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
# Parallelized simulation for B replications
#––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––

rm(list = ls())
setwd('C:/Users/eunic/Dropbox/data_eco/Udesa/mater_thesis/code')

# 0) load your util functions
source("util_functions_jp.R")

# 1) setup parallel backend
library(foreach)
library(doParallel)

ncores <- parallel::detectCores() - 1
cl     <- makeCluster(ncores)
registerDoParallel(cl)

# 2) simulation settings
B <- 20
est_labels <- c(
  "theta0",
  "oracle",
  paste0("dml.ols.K",   c(5,10)),
  paste0("dml.nw.K",    c(5,10)),
  paste0("dml.poly2.K", c(5,10)),
  paste0("dml.poly5.K", c(5,10)),
  paste0("dml.poly10.K",c(5,10)),
  paste0("adml1.poly2.K", c(5,10)),
  paste0("adml1.poly5.K", c(5,10)),
  paste0("adml1.poly10.K",c(5,10)),
  paste0("adml2.poly2.K", c(5,10)),
  paste0("adml2.poly5.K", c(5,10)),
  paste0("adml2.poly10.K",c(5,10))
)
P <- length(est_labels)

# 3) run the replications in parallel
res_list <- foreach(b = 1:B,
                    .packages = c("np"),             # add any pkgs your util functions need
                    .export   = c("generate_data",
                                  "oracle_dr","dml_dr",
                                  "adml1_dr","adml2_dr")
) %dopar% {
  # 3.1 draw DGP
  dat    <- generate_data(model = "probit", seed = b, n = 400)
  theta0 <- mean(dat$gx)
  
  # 3.2 oracle
  or <- oracle_dr(dat)
  
  # 3.3 containers
  est <- numeric(P)
  se  <- numeric(P)
  
  # 3.4 fill in
  est[1] <- theta0;    se[1] <- NA
  est[2] <- or["est"]; se[2] <- or["se"]
  
  idx <- 3
  # DML: ols & nw
  for(m in c("ols","nw")) for(K in c(5,10)) {
    tmp     <- dml_dr(dat, est = m, K = K)
    est[idx] <- tmp["est"]
    se[idx]  <- tmp["se"]
    idx      <- idx + 1
  }
  # DML.poly
  for(p in c(2,5,10)) for(K in c(5,10)) {
    tmp     <- dml_dr(dat, est = "poly", p = p, K = K)
    est[idx] <- tmp["est"]
    se[idx]  <- tmp["se"]
    idx      <- idx + 1
  }
  # ADML1
  for(p in c(2,5,10)) for(K in c(5,10)) {
    tmp     <- adml1_dr(dat, p = p, K = K)
    est[idx] <- tmp["est"]
    se[idx]  <- tmp["se"]
    idx      <- idx + 1
  }
  # ADML2
  for(p in c(2,5,10)) for(K in c(5,10)) {
    tmp     <- adml2_dr(dat, p = p, K = K)
    est[idx] <- tmp["est"]
    se[idx]  <- tmp["se"]
    idx      <- idx + 1
  }
  
  list(est = est, se = se, theta0 = theta0)
}

# 4) stop the cluster
stopCluster(cl)

# 5) combine results into matrices
est_mat    <- t(sapply(res_list, `[[`, "est"))
se_mat     <- t(sapply(res_list, `[[`, "se"))
theta0_vec <- sapply(res_list, `[[`, "theta0")

# 6) build summary table
summary_tbl <- data.frame(
  estimator   = est_labels,
  mean.theta0 = mean(theta0_vec),
  mean.est    = colMeans(est_mat,   na.rm = TRUE),
  mean.bias   = colMeans(theta0_vec - est_mat, na.rm = TRUE),
  mean.se     = colMeans(se_mat,    na.rm = TRUE)
)

# 7) print
print(summary_tbl, digits = 3)
